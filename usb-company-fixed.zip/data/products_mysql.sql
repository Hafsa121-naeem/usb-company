-- ==============================================================================
-- NexDrive USB Storage Solutions - MySQL Database Schema & Seed Data
-- Database: usb_company
-- ==============================================================================

CREATE DATABASE IF NOT EXISTS `usb_company` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `usb_company`;

-- Table structure for table `products`
DROP TABLE IF EXISTS `products`;
CREATE TABLE `products` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(255) NOT NULL,
  `model_code` VARCHAR(100) DEFAULT NULL,
  `image` VARCHAR(500) DEFAULT NULL,
  `capacity` VARCHAR(255) DEFAULT NULL,
  `price` VARCHAR(100) DEFAULT NULL,
  `price_pkr` DECIMAL(10,2) DEFAULT 1200.00,
  `description` TEXT DEFAULT NULL,
  `availability` VARCHAR(50) DEFAULT 'In Stock',
  `category` VARCHAR(100) DEFAULT 'Standard USB',
  `read_speed` VARCHAR(100) DEFAULT NULL,
  `write_speed` VARCHAR(100) DEFAULT NULL,
  `interface` VARCHAR(100) DEFAULT NULL,
  `material` VARCHAR(255) DEFAULT NULL,
  `dimensions` VARCHAR(100) DEFAULT NULL,
  `weight` VARCHAR(50) DEFAULT NULL,
  `warranty` VARCHAR(150) DEFAULT '5-Year Enterprise Replacement Warranty',
  `features` TEXT DEFAULT NULL,
  `stock_quantity` INT DEFAULT 1000,
  `min_order_qty` INT DEFAULT 25,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping initial seed products with PKR pricing & rich specifications
INSERT INTO `products` (
  `name`, `model_code`, `image`, `capacity`, `price`, `price_pkr`,
  `description`, `availability`, `category`, `read_speed`, `write_speed`,
  `interface`, `material`, `dimensions`, `weight`, `warranty`,
  `features`, `stock_quantity`, `min_order_qty`
) VALUES
(
  'Apex Titanium Flash Drive', 'USB-M100', 'images/products/usb-apex-titanium.svg',
  '16GB, 32GB, 64GB, 128GB, 256GB', '₨ 1,250 – ₨ 4,800 / unit', 1250.00,
  'Heavy-duty unibody zinc-alloy flash drive engineered for maximum durability, heat dissipation, and corporate keyring portability. Resistant to water, pressure, and dust.',
  'In Stock', 'Titanium Metal', 'Up to 150 MB/s', 'Up to 60 MB/s',
  'USB 3.2 Gen 1 (Type-A)', 'Die-Cast Zinc Alloy Unibody (Gunmetal Titanium)', '48 × 12.2 × 4.6 mm', '14.5g',
  '5-Year Enterprise Replacement Warranty',
  'Monocoque zinc-alloy casing\nIPX7 water & dust resistant\nHigh-retention 3D TLC NAND\nLaser engraved corporate branding area\nIntegrated keyring loop',
  2500, 25
),
(
  'DuoLink Pro Dual OTG Drive', 'USB-D200', 'images/products/usb-duolink-pro.svg',
  '32GB, 64GB, 128GB, 256GB, 512GB', '₨ 1,650 – ₨ 6,500 / unit', 1650.00,
  'Versatile 2-in-1 flash drive featuring reversible USB Type-C and standard USB Type-A connectors for seamless file transfer between smartphones, MacBooks, tablets, and Windows PCs.',
  'In Stock', 'Dual USB-C / OTG', 'Up to 160 MB/s', 'Up to 75 MB/s',
  'Dual USB-C & USB-A 3.2', 'Burnished Anodized Aluminum with 360° Steel Shield', '62 × 18 × 9 mm', '19g',
  '5-Year Enterprise Replacement Warranty',
  'Dual reversible USB-C and USB-A plugs\nInstant plug & play on Android, iOS & PC\n360° swivel protective steel bridge\nHigh thermal dissipation alloy body\nDual-channel SMI controller',
  1800, 25
),
(
  'Orbit Swivel Flash Drive', 'USB-S300', 'images/products/usb-orbit-swivel.svg',
  '8GB, 16GB, 32GB, 64GB, 128GB', '₨ 850 – ₨ 3,200 / unit', 850.00,
  'The corporate industry standard capless 360-degree rotational design featuring a protective aluminum swivel clip and soft-touch body. Large surface area for laser engraving and screen printing.',
  'In Stock', 'Capless Swivel', 'Up to 90 MB/s', 'Up to 35 MB/s',
  'USB 3.0 / USB 2.0', 'Matte Rubberized ABS Body with Aluminum Swivel Clip', '58 × 19 × 10 mm', '12g',
  '3-Year Enterprise Replacement Warranty',
  'Capless 360-degree rotational design\nLarge dual-side logo imprint zone\nScratch-resistant anodized aluminum clip\nLED data transfer indicator\nAvailable in 12 corporate colorways',
  5000, 50
),
(
  'CardSlim Executive Wafer Drive', 'USB-C400', 'images/products/usb-cardslim-executive.svg',
  '16GB, 32GB, 64GB, 128GB', '₨ 950 – ₨ 3,600 / unit', 950.00,
  'Ultra-slim 2.2mm form factor with flip-out USB connector styled identically to a standard business card. Fits perfectly in wallets with full-bleed double-sided photographic UV imprint area.',
  'Made to Order', 'Credit Card Wafer', 'Up to 80 MB/s', 'Up to 30 MB/s',
  'USB 3.0 Monolithic UDP', 'Ultra-Thin Polymorphic ABS Card with Flip-out UDP Chip', '85.5 × 54 × 2.2 mm', '9.5g',
  '3-Year Enterprise Replacement Warranty',
  'Exact credit card form factor (2.2mm thin)\nFull-bleed edge-to-edge photo UV printing\nFits seamlessly in wallets & badge holders\nWaterproof monolithic UDP flash chip\nHigh-impact promotional gifting medium',
  3200, 50
),
(
  'SecureVault Key Flash Drive', 'USB-K500', 'images/products/usb-securevault-key.svg',
  '32GB, 64GB, 128GB, 256GB', '₨ 1,800 – ₨ 6,200 / unit', 1800.00,
  'IPX8 waterproof monolithic UDP chip architecture shaped like a standard key for everyday keyring carry. Scratch-resistant, shockproof, and ideal for confidential file distribution.',
  'In Stock', 'Waterproof Key', 'Up to 140 MB/s', 'Up to 55 MB/s',
  'USB 3.2 Gen 1 UDP', 'Polished Chrome Steel Key Alloy Monolith', '57 × 24 × 3 mm', '16g',
  '5-Year Enterprise Replacement Warranty',
  'Architectural key design blends with house/office keys\nIPX8 waterproof & 1-ton pressure resistant\nMonolithic chip-on-board (COB) technology\nHardware write-protect partition support\nPrecision laser engravable surface',
  1500, 25
),
(
  'EcoBamboo Wood Drive', 'USB-E600', 'images/products/usb-ecobamboo-wood.svg',
  '16GB, 32GB, 64GB, 128GB', '₨ 1,400 – ₨ 4,200 / unit', 1400.00,
  'FSC-certified organic bamboo wood housing with magnetic cap closure. Sustainable natural aesthetic tailored for eco-conscious corporate gifting, environmental summits, and ESG initiatives.',
  'Bulk Only', 'Eco Wood', 'Up to 100 MB/s', 'Up to 40 MB/s',
  'USB 3.0 Interface', '100% FSC-Certified Natural Organic Bamboo Wood', '60 × 20 × 10 mm', '13g',
  '3-Year Enterprise Replacement Warranty',
  '100% Biodegradable renewable organic bamboo casing\nMagnetic closure cap system\nDeep laser engraving with burnished contrast\nLow-carbon sustainable corporate gifting\nEco-friendly kraft presentation box included',
  2200, 50
);
